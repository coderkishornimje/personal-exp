import "./styles.css";
import React, { useEffect, useState } from "react";
export default function App() {
  const [count, setCount] = useState(0);
  const [timer, setTimer] = useState(false);
  const [timerId, setTimerId] = useState(0);

  useEffect(() => {
    let intervalID = null;

    if (timer) {
      intervalID = setInterval(() => {
        setCount((prev) => prev + 1);
      }, 1000);

      setTimerId(intervalID);
    } else {
      clearInterval(timerId);
    }
  }, [timer]);

  return (
    <div className="App">
      <h1 id="heading">Count Machine</h1>

      <h1 id="count">{count}</h1>

      <button onClick={() => setTimer(true)}>START</button>
      <button id="stop" onClick={() => setTimer(false)}>
        STOP
      </button>
    </div>
  );
}
